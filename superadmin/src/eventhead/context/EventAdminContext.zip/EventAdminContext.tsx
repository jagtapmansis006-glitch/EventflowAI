import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { EventData, UserSession, AuditRecord } from '../types.ts';

interface SimulationState {
  isOpen: boolean;
  data: any | null;
  loading: boolean;
}

interface EventAdminContextType {
  session: UserSession | null;
  event: EventData | null;
  allEvents: EventData[];
  loading: boolean;
  error: string | null;
  activeTab: 'COMMAND_CENTER' | 'LIVE_MAP' | 'EVENT_REPORT';
  setActiveTab: (tab: 'COMMAND_CENTER' | 'LIVE_MAP' | 'EVENT_REPORT') => void;
  selectedItem: { type: 'GATE' | 'QUEUE' | 'ZONE' | 'CAMERA' | 'INCIDENT'; data: any } | null;
  setSelectedItem: (item: { type: 'GATE' | 'QUEUE' | 'ZONE' | 'CAMERA' | 'INCIDENT'; data: any } | null) => void;
  simulation: SimulationState;
  openSimulation: (action: string, targetId?: string, prefill?: any) => Promise<void>;
  closeSimulation: () => void;
  applySimulation: (actionPayload: any) => Promise<void>;
  voiceOpen: boolean;
  setVoiceOpen: (open: boolean) => void;
  voiceLogs: { id: string; role: 'user' | 'assistant'; text: string; time: string; actionExecuted?: boolean }[];
  executeVoice: (command: string, confirmed?: boolean) => Promise<{ status: string; voiceResponse: string; requiresConfirmation?: boolean }>;
  toggleGate: (gateId: string, status?: 'OPEN' | 'CLOSED', source?: string) => Promise<void>;
  redirectRoute: (routeId: string) => Promise<void>;
  handleAlertAction: (alertId: string, actionType: string, payload?: any) => Promise<void>;
  dispatchIncidentStaff: (incidentId: string) => Promise<void>;
  switchUserRole: (role: 'EVENT_ADMIN' | 'SUPER_ADMIN', targetEventId?: string) => Promise<void>;
  createEventBySuperAdmin: (formData: any) => Promise<EventData | null>;
  auditLogs: AuditRecord[];
  fetchAuditLogs: () => Promise<void>;
  refreshEvent: () => Promise<void>;
}

const EventAdminContext = createContext<EventAdminContextType | undefined>(undefined);

export const EventAdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<UserSession | null>(null);
  const [event, setEvent] = useState<EventData | null>(null);
  const [allEvents, setAllEvents] = useState<EventData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'COMMAND_CENTER' | 'LIVE_MAP' | 'EVENT_REPORT'>('COMMAND_CENTER');
  const [selectedItem, setSelectedItem] = useState<{ type: 'GATE' | 'QUEUE' | 'ZONE' | 'CAMERA' | 'INCIDENT'; data: any } | null>(null);
  
  const [simulation, setSimulation] = useState<SimulationState>({
    isOpen: false,
    data: null,
    loading: false,
  });

  const [voiceOpen, setVoiceOpen] = useState(false);
  const [voiceLogs, setVoiceLogs] = useState<{ id: string; role: 'user' | 'assistant'; text: string; time: string; actionExecuted?: boolean }[]>([
    {
      id: 'init_1',
      role: 'assistant',
      text: 'EventFlow Voice Assistant online. Speak a command like "Hey, open Gate 3", "What\'s the current crowd?", or "Show me Zone B".',
      time: 'Ready',
    },
  ]);
  const [auditLogs, setAuditLogs] = useState<AuditRecord[]>([]);

  // Fetch Session
  const fetchSession = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        setSession(data);
        return data;
      }
    } catch (err) {
      console.error('Failed to fetch session', err);
    }
    return null;
  }, []);

  // Fetch Event
  const fetchEvent = useCallback(async (eventId?: string) => {
    try {
      setError(null);
      // First get events list
      const res = await fetch('/api/events');
      if (!res.ok) {
        throw new Error('Failed to load assigned events.');
      }
      const list: EventData[] = await res.json();
      setAllEvents(list);

      const targetId = eventId || list[0]?.id;
      if (!targetId) {
        setError('No active event assigned.');
        return;
      }

      const eventRes = await fetch(`/api/events/${targetId}`);
      if (!eventRes.ok) {
        const errJson = await eventRes.json();
        throw new Error(errJson.error || 'Failed to fetch event details.');
      }
      const eventData: EventData = await eventRes.json();
      setEvent(eventData);

      // Also refresh selectedItem if open
      setSelectedItem(prev => {
        if (!prev) return null;
        if (prev.type === 'GATE') {
          const fresh = eventData.gates.find(g => g.id === prev.data.id);
          return fresh ? { type: 'GATE', data: fresh } : prev;
        }
        if (prev.type === 'ZONE') {
          const fresh = eventData.zones.find(z => z.id === prev.data.id);
          return fresh ? { type: 'ZONE', data: fresh } : prev;
        }
        if (prev.type === 'QUEUE') {
          const fresh = eventData.queues.find(q => q.id === prev.data.id);
          return fresh ? { type: 'QUEUE', data: fresh } : prev;
        }
        if (prev.type === 'CAMERA') {
          const fresh = eventData.cameras.find(c => c.id === prev.data.id);
          return fresh ? { type: 'CAMERA', data: fresh } : prev;
        }
        if (prev.type === 'INCIDENT') {
          const fresh = eventData.incidents.find(i => i.id === prev.data.id);
          return fresh ? { type: 'INCIDENT', data: fresh } : prev;
        }
        return prev;
      });
    } catch (err: any) {
      setError(err.message || 'Error loading event.');
    }
  }, []);

  const fetchAuditLogs = useCallback(async () => {
    if (!event) return;
    try {
      const res = await fetch(`/api/events/${event.id}/audit-logs`);
      if (res.ok) {
        const data = await res.json();
        setAuditLogs(data);
      }
    } catch (err) {
      console.error('Failed to fetch audit logs', err);
    }
  }, [event]);

  // Initial load
  useEffect(() => {
    let mounted = true;
    async function init() {
      setLoading(true);
      const sess = await fetchSession();
      if (mounted) {
        await fetchEvent(sess?.assignedEventId);
        setLoading(false);
      }
    }
    init();
    return () => {
      mounted = false;
    };
  }, [fetchSession, fetchEvent]);

  // Polling for live crowd & telemetry updates (every 3 seconds)
  useEffect(() => {
    if (!event) return;
    const interval = setInterval(() => {
      fetchEvent(event.id);
    }, 3500);
    return () => clearInterval(interval);
  }, [event?.id, fetchEvent]);

  // Toggle Gate
  const toggleGate = async (gateId: string, status?: 'OPEN' | 'CLOSED', source = 'ui') => {
    if (!event) return;
    try {
      const res = await fetch(`/api/events/${event.id}/gates/${gateId}/toggle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, source }),
      });
      if (res.ok) {
        const data = await res.json();
        setEvent(data.event);
        fetchAuditLogs();
      }
    } catch (err) {
      console.error('Failed to toggle gate', err);
    }
  };

  // Redirect Route
  const redirectRoute = async (routeId: string) => {
    if (!event) return;
    try {
      const res = await fetch(`/api/events/${event.id}/routes/${routeId}/redirect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'REDIRECTED', source: 'ui' }),
      });
      if (res.ok) {
        const data = await res.json();
        setEvent(data.event);
        fetchAuditLogs();
      }
    } catch (err) {
      console.error('Failed to redirect route', err);
    }
  };

  // Alert Action
  const handleAlertAction = async (alertId: string, actionType: string, payload?: any) => {
    if (!event) return;
    if (actionType === 'OPEN_GATE' && payload?.gateId) {
      await toggleGate(payload.gateId, 'OPEN', 'ai_apply');
      return;
    }
    if (actionType === 'REDIRECT_ROUTE' && payload?.routeId) {
      await redirectRoute(payload.routeId);
      return;
    }
    if (actionType === 'DISPATCH_STAFF' && payload?.incidentId) {
      await dispatchIncidentStaff(payload.incidentId);
      return;
    }
    // Dismiss/resolve alert
    try {
      const res = await fetch(`/api/events/${event.id}/alerts/${alertId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: actionType }),
      });
      if (res.ok) {
        const data = await res.json();
        setEvent(data.event);
        fetchAuditLogs();
      }
    } catch (err) {
      console.error('Failed alert action', err);
    }
  };

  // Dispatch Incident Staff
  const dispatchIncidentStaff = async (incidentId: string) => {
    if (!event) return;
    try {
      const res = await fetch(`/api/events/${event.id}/incidents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'DISPATCH_STAFF', incidentId }),
      });
      if (res.ok) {
        const data = await res.json();
        setEvent(data.event);
        fetchAuditLogs();
      }
    } catch (err) {
      console.error('Failed to dispatch staff', err);
    }
  };

  // Simulation
  const openSimulation = async (action: string, targetId?: string, prefill?: any) => {
    if (!event) return;
    setSimulation({
      isOpen: true,
      data: prefill || null,
      loading: !prefill,
    });

    if (!prefill) {
      try {
        const res = await fetch(`/api/events/${event.id}/simulate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action, targetId }),
        });
        if (res.ok) {
          const data = await res.json();
          setSimulation({ isOpen: true, data, loading: false });
        }
      } catch (err) {
        console.error('Simulation error', err);
        setSimulation(prev => ({ ...prev, loading: false }));
      }
    }
  };

  const closeSimulation = () => {
    setSimulation({ isOpen: false, data: null, loading: false });
  };

  const applySimulation = async (actionPayload: any) => {
    if (!actionPayload) return;
    if (actionPayload.action === 'OPEN_GATE') {
      await toggleGate(actionPayload.targetId, 'OPEN', 'ai_apply');
    } else if (actionPayload.action === 'REDIRECT_ROUTE') {
      await redirectRoute(actionPayload.targetId);
    }
    closeSimulation();
  };

  // Voice Command Execution
  const executeVoice = async (command: string, confirmed = false): Promise<{ status: string; voiceResponse: string; requiresConfirmation?: boolean }> => {
    if (!event) return { status: 'ERROR', voiceResponse: 'No event active.' };

    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    setVoiceLogs(prev => [
      ...prev,
      { id: `u_${Date.now()}`, role: 'user', text: command, time: timeStr },
    ]);

    try {
      const res = await fetch(`/api/events/${event.id}/voice-command`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, confirmed }),
      });
      const data = await res.json();

      if (data.event) {
        setEvent(data.event);
        fetchAuditLogs();
      }

      const responseText = data.voiceResponse || data.message || 'Command executed.';
      setVoiceLogs(prev => [
        ...prev,
        {
          id: `a_${Date.now()}`,
          role: 'assistant',
          text: responseText,
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          actionExecuted: data.status === 'EXECUTED',
        },
      ]);

      // Voice audio feedback via Web Speech Synthesis if supported
      if ('speechSynthesis' in window && responseText) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(responseText);
        utterance.rate = 1.05;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
      }

      // If command requested showing simulation or zone
      if (data.status === 'OPEN_SIMULATION') {
        openSimulation('OPEN_GATE', 'gate_3');
      } else if (data.status === 'NAVIGATE' && data.action === 'SHOW_ZONE' && data.target) {
        const foundZone = event.zones.find(z => z.id === data.target);
        if (foundZone) setSelectedItem({ type: 'ZONE', data: foundZone });
      }

      return {
        status: data.status,
        voiceResponse: responseText,
        requiresConfirmation: data.requiresConfirmation,
      };
    } catch (err: any) {
      const errText = 'Failed to execute voice command: ' + (err.message || 'network error');
      setVoiceLogs(prev => [
        ...prev,
        { id: `a_${Date.now()}`, role: 'assistant', text: errText, time: timeStr },
      ]);
      return { status: 'ERROR', voiceResponse: errText };
    }
  };

  // Switch Role
  const switchUserRole = async (role: 'EVENT_ADMIN' | 'SUPER_ADMIN', targetEventId?: string) => {
    try {
      setLoading(true);
      const res = await fetch('/api/auth/switch-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, assignedEventId: targetEventId }),
      });
      if (res.ok) {
        const data = await res.json();
        setSession(data.session);
        await fetchEvent(data.session.assignedEventId);
      }
    } catch (err) {
      console.error('Failed to switch role', err);
    } finally {
      setLoading(false);
    }
  };

  // Super Admin: Create Event
  const createEventBySuperAdmin = async (formData: any): Promise<EventData | null> => {
    try {
      const res = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        const created: EventData = await res.json();
        setAllEvents(prev => [...prev, created]);
        return created;
      }
    } catch (err) {
      console.error('Failed to create event', err);
    }
    return null;
  };

  const refreshEvent = async () => {
    if (event?.id) await fetchEvent(event.id);
  };

  return (
    <EventAdminContext.Provider
      value={{
        session,
        event,
        allEvents,
        loading,
        error,
        activeTab,
        setActiveTab,
        selectedItem,
        setSelectedItem,
        simulation,
        openSimulation,
        closeSimulation,
        applySimulation,
        voiceOpen,
        setVoiceOpen,
        voiceLogs,
        executeVoice,
        toggleGate,
        redirectRoute,
        handleAlertAction,
        dispatchIncidentStaff,
        switchUserRole,
        createEventBySuperAdmin,
        auditLogs,
        fetchAuditLogs,
        refreshEvent,
      }}
    >
      {children}
    </EventAdminContext.Provider>
  );
};

export const useEventAdmin = () => {
  const ctx = useContext(EventAdminContext);
  if (!ctx) throw new Error('useEventAdmin must be used within EventAdminProvider');
  return ctx;
};
