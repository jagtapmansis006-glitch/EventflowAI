import React, { useEffect, useRef, useState } from 'react';
import { useEventAdmin } from '../context/EventAdminContext.tsx';
import { 
  Hotel,
  Utensils,
  Toilet,
  Car,
  Bus,
  TrafficCone,
  RefreshCw,
  Minus,
  Plus,
  Maximize2,
  X,
  Sparkles,
  SlidersHorizontal,
  DoorClosed,
  DoorOpen
} from 'lucide-react';
import { importLibrary, setOptions } from '@googlemaps/js-api-loader';

const GOOGLE_MAPS_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";
const JIO_WORLD_CENTER = { lat: 19.0635, lng: 72.86744 };

type MapFilter = 'ALL' | 'CROWD' | 'GATES' | 'ROUTES' | 'INCIDENTS' | 'CAMERAS';
type ResourceType = 'hotels' | 'restaurants' | 'washrooms' | 'parking' | 'transport';

interface SelectedGateInfo {
  id: string;
  name: string;
  locationName: string;
  status: 'OPEN' | 'CONGESTED' | 'CLOSED';
  currentCrowd: number;
  totalCapacity: number;
  flowRate: number;
  occupancyPercent: number;
  predictionText: string;
}

export const LiveMap: React.FC = () => {
  const { event, setSelectedItem } = useEventAdmin();
  const [filter, setFilter] = useState<MapFilter>('ALL');
  const [zoom, setZoom] = useState(16);
  const [mapReady, setMapReady] = useState(false);
  const [loadingResources, setLoadingResources] = useState(false);

  const [activeGate, setActiveGate] = useState<SelectedGateInfo | null>(null);

  const [layers, setLayers] = useState({
    hotels: false,
    restaurants: false,
    washrooms: false,
    parking: false,
    transport: false,
    traffic: false,
  });

  const mapRef = useRef<HTMLDivElement | null>(null);
  const mapInstance = useRef<google.maps.Map | null>(null);
  const trafficLayerRef = useRef<google.maps.TrafficLayer | null>(null);
  const operationalObjectsRef = useRef<(google.maps.Marker | google.maps.Circle | google.maps.Polyline | google.maps.Polygon)[]>([]);
  const resourceMarkersRef = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    if (!mapRef.current || !GOOGLE_MAPS_KEY) return;
    let isCancelled = false;

    async function initMap() {
      try {
        setOptions({ key: GOOGLE_MAPS_KEY, v: 'weekly' });
        await importLibrary('maps');

        if (isCancelled || !mapRef.current) return;

        const map = new google.maps.Map(mapRef.current, {
          center: JIO_WORLD_CENTER,
          zoom: 16,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false,
          zoomControl: false,
          styles: [
            { featureType: "poi", elementType: "labels", stylers: [{ visibility: "off" }] }
          ]
        });

        mapInstance.current = map;
        const traffic = new google.maps.TrafficLayer();
        trafficLayerRef.current = traffic;

        setMapReady(true);
      } catch (err) {
        console.error("Google Maps load error:", err);
      }
    }

    initMap();
    return () => { isCancelled = true; };
  }, []);

  useEffect(() => {
    if (!trafficLayerRef.current || !mapInstance.current) return;
    trafficLayerRef.current.setMap(layers.traffic ? mapInstance.current : null);
  }, [layers.traffic, mapReady]);

  const clearOperational = () => {
    operationalObjectsRef.current.forEach(obj => obj.setMap(null));
    operationalObjectsRef.current = [];
  };

  useEffect(() => {
    if (!mapReady || !mapInstance.current) return;
    clearOperational();
    const map = mapInstance.current;

    const showCrowd = filter === 'ALL' || filter === 'CROWD';
    const showGates = filter === 'ALL' || filter === 'GATES';
    const showRoutes = filter === 'ALL' || filter === 'ROUTES';
    const showCameras = filter === 'ALL' || filter === 'CAMERAS';
    const showIncidents = filter === 'ALL' || filter === 'INCIDENTS';

    const zones = [
      { id: 'zone-a', name: 'Zone A', density: 86, lat: 19.0620, lng: 72.8655, color: '#f59e0b', radius: 95 },
      { id: 'zone-b', name: 'Zone B', density: 92, lat: 19.0635, lng: 72.8675, color: '#ef4444', radius: 125 },
      { id: 'zone-c', name: 'Zone C', density: 66, lat: 19.0622, lng: 72.8698, color: '#10b981', radius: 105 },
      { id: 'zone-d', name: 'Zone D', density: 75, lat: 19.0648, lng: 72.8658, color: '#f59e0b', radius: 100 },
    ];

    if (showCrowd) {
      zones.forEach(z => {
        const circle = new google.maps.Circle({
          map,
          center: { lat: z.lat, lng: z.lng },
          radius: z.radius,
          fillColor: z.color,
          fillOpacity: 0.16,
          strokeColor: z.color,
          strokeWeight: 2,
          clickable: true,
        });

        circle.addListener('click', () => setSelectedItem?.({ type: 'ZONE', data: z }));
        operationalObjectsRef.current.push(circle);

        const label = new google.maps.Marker({
          map,
          position: { lat: z.lat, lng: z.lng },
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 },
          label: {
            text: `${z.name} • ${z.density}%`,
            color: '#1e293b',
            fontSize: '11px',
            fontWeight: 'bold',
          },
          clickable: false,
        });
        operationalObjectsRef.current.push(label);
      });
    }

    if (showRoutes) {
      const routes = [
        { path: [{ lat: 19.0615, lng: 72.8650 }, { lat: 19.0645, lng: 72.8702 }], color: '#f97316', weight: 6 },
        { path: [{ lat: 19.0625, lng: 72.8648 }, { lat: 19.0652, lng: 72.8698 }], color: '#64748b', weight: 4 },
        { path: [{ lat: 19.0620, lng: 72.8646 }, { lat: 19.0648, lng: 72.8700 }], color: '#94a3b8', weight: 4 },
      ];

      routes.forEach(r => {
        const line = new google.maps.Polyline({
          map,
          path: r.path,
          strokeColor: r.color,
          strokeWeight: r.weight,
          strokeOpacity: 0.85,
        });
        operationalObjectsRef.current.push(line);
      });
    }

    const gatesData: (SelectedGateInfo & { lat: number; lng: number })[] = [
      {
        id: 'gate_1',
        name: 'Gate 1',
        locationName: 'Gate 1 (East Concourse)',
        status: 'OPEN',
        currentCrowd: 1420,
        totalCapacity: 2500,
        flowRate: 65,
        occupancyPercent: 57,
        predictionText: 'Flow is continuous. Peak entrance expected in 12 mins with metro arrival.',
        lat: 19.0655,
        lng: 72.8652,
      },
      {
        id: 'gate_2',
        name: 'Gate 2',
        locationName: 'Gate 2 (Main Plaza Entrance)',
        status: 'CONGESTED',
        currentCrowd: 3120,
        totalCapacity: 3200,
        flowRate: 114,
        occupancyPercent: 97,
        predictionText: 'High congestion detected. Choke point spillover towards turnstile bank.',
        lat: 19.0652,
        lng: 72.8670,
      },
      {
        id: 'gate_3',
        name: 'Gate 3',
        locationName: 'Gate 3 (North Auxiliary)',
        status: 'CLOSED',
        currentCrowd: 0,
        totalCapacity: 2000,
        flowRate: 0,
        occupancyPercent: 0,
        predictionText: 'Gate currently closed. Available buffer capacity for diversion from Gate 2.',
        lat: 19.0656,
        lng: 72.8682,
      },
      {
        id: 'gate_4',
        name: 'Gate 4',
        locationName: 'Gate 4 (North Wing Ingress)',
        status: 'OPEN',
        currentCrowd: 1180,
        totalCapacity: 2500,
        flowRate: 42,
        occupancyPercent: 47,
        predictionText: 'Nominal intake velocity. Turnstile clearance optimal.',
        lat: 19.0640,
        lng: 72.8708,
      },
      {
        id: 'gate_5',
        name: 'Gate 5',
        locationName: 'Gate 5 (South Transit Exit)',
        status: 'OPEN',
        currentCrowd: 940,
        totalCapacity: 3000,
        flowRate: 28,
        occupancyPercent: 31,
        predictionText: 'Steady outflow stream. Normal shuttle pickup clearance.',
        lat: 19.0608,
        lng: 72.8678,
      },
    ];

    if (showGates) {
      gatesData.forEach(g => {
        const marker = new google.maps.Marker({
          map,
          position: { lat: g.lat, lng: g.lng },
          title: g.locationName,
          label: {
            text: `${g.name} ${g.status}`,
            color: '#0f172a',
            fontSize: '10px',
            fontWeight: 'bold'
          },
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: g.status === 'CONGESTED' ? '#ef4444' : g.status === 'CLOSED' ? '#64748b' : '#10b981',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          }
        });

        marker.addListener('click', () => {
          setActiveGate(g);
          setSelectedItem?.({ type: 'GATE', data: g });
        });

        operationalObjectsRef.current.push(marker);
      });
    }

    if (showCameras) {
      const cameras = [
        { id: 'CAM-01', lat: 19.0614, lng: 72.8660, bearing: 45 },
        { id: 'CAM-02', lat: 19.0632, lng: 72.8692, bearing: -90 },
        { id: 'CAM-03', lat: 19.0642, lng: 72.8664, bearing: 180 },
        { id: 'CAM-04', lat: 19.0618, lng: 72.8688, bearing: 120 },
        { id: 'CAM-05', lat: 19.0628, lng: 72.8660, bearing: 30 },
      ];

      cameras.forEach(c => {
        const camMarker = new google.maps.Marker({
          map,
          position: { lat: c.lat, lng: c.lng },
          title: c.id,
          label: { text: c.id, color: '#0284c7', fontSize: '9px', fontWeight: 'bold' },
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 5,
            fillColor: '#0284c7',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 1.5,
          }
        });
        operationalObjectsRef.current.push(camMarker);

        const rad = (c.bearing * Math.PI) / 180;
        const d = 0.0010;
        const p1 = { lat: c.lat, lng: c.lng };
        const p2 = { lat: c.lat + Math.cos(rad - 0.4) * d, lng: c.lng + Math.sin(rad - 0.4) * d };
        const p3 = { lat: c.lat + Math.cos(rad + 0.4) * d, lng: c.lng + Math.sin(rad + 0.4) * d };

        const fov = new google.maps.Polygon({
          map,
          paths: [p1, p2, p3],
          fillColor: '#0ea5e9',
          fillOpacity: 0.12,
          strokeColor: '#0ea5e9',
          strokeWeight: 1,
          strokeOpacity: 0.4,
          clickable: false,
        });
        operationalObjectsRef.current.push(fov);
      });
    }

    if (showIncidents) {
      const incidentMarker = new google.maps.Marker({
        map,
        position: { lat: 19.0624, lng: 72.8650 },
        title: 'Incident: Medical Assist',
        label: { text: '!', color: '#ffffff', fontSize: '10px', fontWeight: 'bold' },
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 9,
          fillColor: '#ef4444',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        }
      });
      operationalObjectsRef.current.push(incidentMarker);
    }

  }, [mapReady, filter]);

  const loadNearbyResources = async (type: ResourceType) => {
    if (!mapInstance.current) return;
    setLoadingResources(true);

    try {
      await importLibrary('places');
      const service = new google.maps.places.PlacesService(mapInstance.current);

      const placeTypes: Record<ResourceType, { label: string; color: string; type: string }> = {
        hotels: { label: 'Hotels', color: '#2563eb', type: 'lodging' },
        restaurants: { label: 'Food', color: '#ea580c', type: 'restaurant' },
        washrooms: { label: 'Washroom', color: '#7c3aed', type: 'public_bathroom' },
        parking: { label: 'Parking', color: '#334155', type: 'parking' },
        transport: { label: 'Transport', color: '#0891b2', type: 'bus_station' },
      };

      const cfg = placeTypes[type];

      await new Promise<void>((resolve) => {
        service.nearbySearch(
          {
            location: JIO_WORLD_CENTER,
            radius: 3500,
            type: cfg.type as any,
          },
          (results, status) => {
            if (status === google.maps.places.PlacesServiceStatus.OK && results) {
              results.slice(0, 15).forEach(place => {
                if (!place.geometry?.location || !mapInstance.current) return;

                const marker = new google.maps.Marker({
                  map: mapInstance.current,
                  position: place.geometry.location,
                  title: place.name || cfg.label,
                  icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 7,
                    fillColor: cfg.color,
                    fillOpacity: 1,
                    strokeColor: '#ffffff',
                    strokeWeight: 2,
                  }
                });

                const info = new google.maps.InfoWindow({
                  content: `
                    <div style="font-family:sans-serif;padding:3px;">
                      <strong style="font-size:12px;color:#0f172a">${place.name || cfg.label}</strong>
                      <div style="font-size:10px;color:#64748b;margin-top:2px">${place.vicinity || ''}</div>
                    </div>
                  `
                });

                marker.addListener('click', () => info.open({ map: mapInstance.current, anchor: marker }));
                resourceMarkersRef.current.push(marker);
              });
            }
            resolve();
          }
        );
      });
    } catch (e) {
      console.warn("Places fetch error:", e);
    } finally {
      setLoadingResources(false);
    }
  };

  const toggleResource = async (key: keyof typeof layers) => {
    const next = !layers[key];
    setLayers(prev => ({ ...prev, [key]: next }));

    if (key === 'traffic') return;

    if (next) {
      await loadNearbyResources(key as ResourceType);
    } else {
      resourceMarkersRef.current.forEach(m => m.setMap(null));
      resourceMarkersRef.current = [];
    }
  };

  return (
    <div id="live-map-page" className="relative w-full h-[calc(100vh-4.2rem)] overflow-hidden select-none bg-slate-100 flex">
      
      <div className="relative flex-1 h-full">
        <div ref={mapRef} className="absolute inset-0 w-full h-full z-0" />

        <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
          
          <div className="bg-white/95 backdrop-blur-md px-2 py-1.5 rounded-2xl border border-slate-200 shadow-md flex items-center gap-1 pointer-events-auto">
            {(['ALL', 'CROWD', 'GATES', 'ROUTES', 'INCIDENTS', 'CAMERAS'] as MapFilter[]).map(tab => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  filter === tab
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {tab.charAt(0) + tab.slice(1).toLowerCase()}
              </button>
            ))}
          </div>

          <div className="bg-white/95 backdrop-blur-md px-2.5 py-1.5 rounded-2xl border border-slate-200 shadow-md flex items-center gap-1.5 pointer-events-auto text-xs font-semibold">
            <button
              onClick={() => toggleResource('hotels')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer ${
                layers.hotels ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Hotel size={13} />
              <span>Hotels</span>
            </button>

            <button
              onClick={() => toggleResource('restaurants')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer ${
                layers.restaurants ? 'bg-orange-500 text-white border-orange-500' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Utensils size={13} />
              <span>Food</span>
            </button>

            <button
              onClick={() => toggleResource('washrooms')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer ${
                layers.washrooms ? 'bg-purple-600 text-white border-purple-600' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Toilet size={13} />
              <span>Washrooms</span>
            </button>

            <button
              onClick={() => toggleResource('parking')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer ${
                layers.parking ? 'bg-slate-800 text-white border-slate-800' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Car size={13} />
              <span>Parking</span>
            </button>

            <button
              onClick={() => toggleResource('transport')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer ${
                layers.transport ? 'bg-cyan-600 text-white border-cyan-600' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Bus size={13} />
              <span>Transport</span>
            </button>

            <button
              onClick={() => toggleResource('traffic')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer ${
                layers.traffic ? 'bg-rose-600 text-white border-rose-600' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <TrafficCone size={13} />
              <span>Traffic</span>
            </button>
          </div>

          <div className="hidden xl:flex items-center gap-3 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-slate-200 shadow-md text-xs font-medium text-slate-600 pointer-events-auto">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>Normal</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>Busy / High Density</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
              <span>Critical Congestion</span>
            </div>
          </div>

          <div className="bg-white/95 backdrop-blur-md p-1 rounded-2xl border border-slate-200 shadow-md flex items-center gap-1 pointer-events-auto">
            <button
              onClick={() => {
                if (mapInstance.current) {
                  const z = (mapInstance.current.getZoom() || 16) - 1;
                  mapInstance.current.setZoom(z);
                  setZoom(z);
                }
              }}
              className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-700 cursor-pointer"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono font-bold text-slate-700 w-8 text-center">{zoom}</span>
            <button
              onClick={() => {
                if (mapInstance.current) {
                  const z = (mapInstance.current.getZoom() || 16) + 1;
                  mapInstance.current.setZoom(z);
                  setZoom(z);
                }
              }}
              className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-700 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                if (mapInstance.current) {
                  mapInstance.current.panTo(JIO_WORLD_CENTER);
                  mapInstance.current.setZoom(16);
                  setZoom(16);
                }
              }}
              className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-700 ml-0.5 cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="absolute bottom-4 left-4 z-20 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-slate-200 shadow-md text-[11px] font-mono font-bold text-slate-600 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Google Maps + EventFlow Live Telemetry</span>
        </div>

        {loadingResources && (
          <div className="absolute bottom-4 right-4 z-20 bg-white/95 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 flex items-center gap-1.5 shadow-md">
            <RefreshCw className="w-3 h-3 animate-spin text-blue-600" />
            <span>Loading Nearby Places...</span>
          </div>
        )}
      </div>

      {activeGate && (
        <aside className="w-80 sm:w-96 bg-white border-l border-slate-200 shadow-2xl z-30 flex flex-col justify-between p-5 animate-in slide-in-from-right duration-200 overflow-y-auto">
          <div className="space-y-6">
            
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 block">
                  GATE TELEMETRY &amp; CONTROLS
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-0.5 flex items-center gap-2">
                  <DoorOpen className="w-4 h-4 text-blue-600" />
                  {activeGate.locationName}
                </h3>
              </div>
              <button
                onClick={() => setActiveGate(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-50">
                <span className="text-slate-500 font-medium">Operating Status</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                  activeGate.status === 'CONGESTED' 
                    ? 'bg-rose-100 text-rose-700' 
                    : activeGate.status === 'CLOSED'
                    ? 'bg-slate-100 text-slate-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {activeGate.status}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50 font-mono">
                <span className="text-slate-500 font-sans font-medium">Current Crowd</span>
                <strong className="text-slate-800">{activeGate.currentCrowd.toLocaleString()} attendees</strong>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50 font-mono">
                <span className="text-slate-500 font-sans font-medium">Total Capacity</span>
                <strong className="text-slate-800">{activeGate.totalCapacity.toLocaleString()} max</strong>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-50 font-mono">
                <span className="text-slate-500 font-sans font-medium">Current Flow Rate</span>
                <strong className={activeGate.flowRate > 80 ? 'text-rose-600' : 'text-emerald-600'}>
                  +{activeGate.flowRate}/min
                </strong>
              </div>

              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between text-[11px] font-medium">
                  <span className="text-slate-500">Occupancy</span>
                  <span className="font-mono font-bold text-slate-700">{activeGate.occupancyPercent}%</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      activeGate.occupancyPercent >= 90
                        ? 'bg-rose-500'
                        : activeGate.occupancyPercent >= 75
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${activeGate.occupancyPercent}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200/80 space-y-1">
              <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                AI Optical Sensor Prediction
              </span>
              <p className="text-[11px] text-blue-700 leading-relaxed">
                {activeGate.predictionText}
              </p>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 space-y-2">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block mb-2">
              GATE DIRECT CONTROLS
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setActiveGate(prev => prev ? ({
                    ...prev,
                    status: prev.status === 'CLOSED' ? 'OPEN' : 'CLOSED',
                    flowRate: prev.status === 'CLOSED' ? 45 : 0
                  }) : null);
                }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer transition ${
                  activeGate.status === 'CLOSED'
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-rose-600 hover:bg-rose-700 text-white'
                }`}
              >
                <DoorClosed className="w-3.5 h-3.5" />
                <span>{activeGate.status === 'CLOSED' ? 'OPEN GATE' : 'CLOSE GATE'}</span>
              </button>

              <button
                onClick={() => {
                  alert(`Opening Diversion Simulator for ${activeGate.name}`);
                }}
                className="flex-1 py-2 rounded-xl text-xs font-bold border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center justify-center gap-1.5 cursor-pointer transition"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-blue-600" />
                <span>SIMULATE</span>
              </button>
            </div>
          </div>
        </aside>
      )}

    </div>
  );
};